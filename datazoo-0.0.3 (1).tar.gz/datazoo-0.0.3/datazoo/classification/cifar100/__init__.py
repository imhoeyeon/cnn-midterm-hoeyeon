from .cifar100 import CIFAR100
__all__ = ['CIFAR100']
