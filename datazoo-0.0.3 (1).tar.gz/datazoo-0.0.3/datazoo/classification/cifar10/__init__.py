from .cifar10 import CIFAR10
__all__ = ['CIFAR10']
