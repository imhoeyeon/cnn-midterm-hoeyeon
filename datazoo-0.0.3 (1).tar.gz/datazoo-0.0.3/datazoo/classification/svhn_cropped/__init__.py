from .svhn_cropped import SVHN_cropped
__all__ = ['SVHN_cropped']
