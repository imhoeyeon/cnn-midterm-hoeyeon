from .fashion_mnist import FashionMNIST
__all__ = ['FashionMNIST']
