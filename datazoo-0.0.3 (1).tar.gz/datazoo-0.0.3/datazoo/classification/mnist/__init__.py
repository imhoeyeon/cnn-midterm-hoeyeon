from .mnist import MNIST
__all__ = ['MNIST']
